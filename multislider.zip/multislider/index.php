<?php 
session_start();

include "db.php";
$catogory=mysqli_query($conn,"SELECT * from catogory_master ORDER BY cname");
$nrow=mysqli_num_rows($catogory);

$sql=mysqli_query($conn,"SELECT * from products  where catogory='house hold' ORDER BY discountper desc ");
$num=mysqli_num_rows($sql);
// $row=mysqli_fetch_array($sql);
// echo '<img src="uploads/'.$row['image'].'" />';

$food=mysqli_query($conn,"SELECT * from products  where catogory='food product' or catogory='food products' ORDER BY discountper desc ");
$fnum=mysqli_num_rows($food);

$baby=mysqli_query($conn,"SELECT * from products where catogory='baby care' ORDER BY discountper desc");
$bnum=mysqli_num_rows($baby);

$sql2=mysqli_query($conn,"SELECT * from products  ORDER BY discountper desc LIMIT 10");
$num2=mysqli_num_rows($sql2);

if(isset($_POST['login'])){
	$user = $_POST['user']; 
	$password = $_POST['password'];
	
	
	$login = mysqli_query($conn,"SELECT * from user where name='$user' and password='$password' ");
	$row = mysqli_num_rows($login);
	$array = mysqli_fetch_array($login);
	
	if($row == 1){
			header( "location:user_login.php");
			$_SESSION['username'] = $user;
			exit;
	}
	else{
			echo "fail";
	}
}

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Multislider</title>

    <!-- CSS -->
    <link href="css/custom.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

  </head>
  <body>
      
    <h1>Multislider</h1>
    <h2>A responsive, jQuery powered, mutli-slideshow.</h2>
    
    <div id="exampleSlider">
    
       <div class="MS-content">
       <?php while($row=mysqli_fetch_array($sql)){ ?>
           <div class="item">
               <p><img src="../uploads/<?php echo $row['image'];?>" alt="img"  style="height:170px;width:110px;"><br>1</p>
           </div>
           <?php } ?>
       </div>
       
       <div class="MS-controls">
           <button class="MS-left"><i class="fa fa-chevron-left" aria-hidden="true"></i></button>
           <button class="MS-right"><i class="fa fa-chevron-right" aria-hidden="true"></i></button>
       </div>
       
   </div>

    <!-- Include jQuery -->
    <script src="js/jquery-2.2.4.min.js"></script>

    <!-- Include Multislider -->
    <script src="js/multislider.min.js"></script>

    <!-- Initialize element with Multislider -->
    <script>
    $('#exampleSlider').multislider({
        interval: 4000,
        slideAll: true,
        duration: 1500
    });
    </script>
  </body>
</html>
